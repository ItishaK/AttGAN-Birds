
**************** CUB-200-2011 Dataset Extraction ****************

1. Download the CUB-200-2011 dataset zip file from the link: https://data.caltech.edu/records/20098
2. Unzip the downloaded file and copy all the image folders inside the directory: /CUB_200_2011/images in your model directory location such as: AttGAN-CUB_200_Birds\data\images

*************** Data Parsing for Semantic attributes *************

* The other files utilized from the CUB-200-2011 dataset zip file are: "attributes.txt", "images.txt" and "attributes/image_attribute_labels.txt". 

* All these files are input to "data_parser.py" file which performs the data preprocessing in order to create the three required label files: 'train_label.txt', 'test_label.txt' and 'val_label.txt' files.

* The 15 attributes considered for the training of this AttGAN model are as follows:
	## has_primary_color_blue
	## has_primary_color_brown
	## has_primary_color_black
	## has_primary_color_grey
	## has_primary_color_white
	## has_underparts_color_white
	## has_underparts_color_grey
	## has_underparts_color_blue
	## has_underparts_color_black
	## has_underparts_color_brown
	## has_upperparts_color_white
	## has_upperparts_color_black
	## has_upperparts_color_grey
	## has_upperparts_color_blue
	## has_upperparts_color_brown

